package com.ak.discipline;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import org.json.JSONArray;
import org.json.JSONObject;

public class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "ak_os_reminders";
    @Override public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()) || "android.intent.action.MY_PACKAGE_REPLACED".equals(intent.getAction())) {
            String json=context.getSharedPreferences("ak_os_alarm_store",Context.MODE_PRIVATE).getString("reminders_json","[]");
            try { JSONArray a=new JSONArray(json); for(int i=0;i<a.length();i++){JSONObject r=a.optJSONObject(i);if(r!=null&&r.optBoolean("active",true))MainActivity.scheduleOne(context,r.optString("id"),r.optString("name","Reminder"),r.optString("type","Custom"),r.optString("time","09:00"),Math.max(0,r.optInt("every",0)));} } catch(Exception ignored){}
            return;
        }
        String id=intent.getStringExtra("id"), name=intent.getStringExtra("name"), type=intent.getStringExtra("type"), time=intent.getStringExtra("time");
        int every=intent.getIntExtra("every",0);
        showNotification(context,id,name,type,false);
        // Schedule the next occurrence. A time-based reminder repeats daily; interval reminders repeat at their interval.
        MainActivity.scheduleOne(context,id,name,type,time, every);
    }

    static void showNotification(Context context,String id,String name,String type,boolean test) {
        Intent open=new Intent(context,MainActivity.class); open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content=PendingIntent.getActivity(context,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        String title=test?name:"⏰ A.K. OS · "+(type==null?"Reminder":type);
        String body=test?"Notifications and vibration test":"It's time for "+(name==null?"your reminder":name)+". Tap to open Discipline.";
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= 26) builder = new Notification.Builder(context, CHANNEL_ID);
        else builder = new Notification.Builder(context);
        Notification n=builder.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(title).setContentText(body)
            .setStyle(new Notification.BigTextStyle().bigText(body)).setContentIntent(content).setAutoCancel(true)
            .setVibrate(new long[]{0,900,350,900,350,1200}).setDefaults(Notification.DEFAULT_SOUND).build();
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm!=null)nm.notify(id==null?1:id.hashCode(),n);
        try {
            Vibrator v;
            if(Build.VERSION.SDK_INT>=31){VibratorManager vm=(VibratorManager)context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE);v=vm==null?null:vm.getDefaultVibrator();}
            else v=(Vibrator)context.getSystemService(Context.VIBRATOR_SERVICE);
            if(v!=null&&v.hasVibrator()){
                long[] pattern={0,900,350,900,350,1200};
                if(Build.VERSION.SDK_INT>=26)v.vibrate(VibrationEffect.createWaveform(pattern,-1));else v.vibrate(pattern,-1);
            }
        }catch(Exception ignored){}
    }
}
