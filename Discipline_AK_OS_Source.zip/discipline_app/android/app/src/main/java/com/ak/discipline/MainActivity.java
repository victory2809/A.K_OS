package com.ak.discipline;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Calendar;

public class MainActivity extends Activity {
    private WebView web;
    private static final String CHANNEL_ID = "ak_os_reminders";
    private static final String PREFS = "ak_os_alarm_store";
    private static final String REMINDERS = "reminders_json";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(8,9,12));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(8,9,12));
        createNotificationChannel();
        web = new WebView(this);
        web.setBackgroundColor(android.graphics.Color.rgb(8,9,12));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        s.setSupportZoom(false); s.setBuiltInZoomControls(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new AlarmBridge(this), "AKAlarm");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        requestNotificationPermissionIfNeeded();
        rescheduleSavedReminders();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Discipline reminders", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Water, meal, gym, study and habit reminders");
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{0, 900, 350, 900, 350, 1200});
            channel.setBypassDnd(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 501);
        }
    }

    private void rescheduleSavedReminders() {
        String json = getSharedPreferences(PREFS, MODE_PRIVATE).getString(REMINDERS, "[]");
        scheduleAll(json);
    }

    private void scheduleAll(String json) {
        try {
            JSONArray list = new JSONArray(json);
            AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
            if (am == null) return;
            // Cancel old alarms for every reminder ID stored in the old/current JSON.
            for (int i=0; i<list.length(); i++) {
                JSONObject r = list.optJSONObject(i); if (r == null) continue;
                String id = r.optString("id", ""); if (id.isEmpty()) continue;
                cancelAlarm(id);
            }
            for (int i=0; i<list.length(); i++) {
                JSONObject r = list.optJSONObject(i); if (r == null || !r.optBoolean("active", true)) continue;
                String id=r.optString("id", ""), name=r.optString("name", "Reminder"), type=r.optString("type", "Custom"), time=r.optString("time", "09:00");
                int every=Math.max(0, r.optInt("every", 0));
                if (!id.isEmpty()) scheduleOne(id,name,type,time,every);
            }
        } catch (Exception ignored) { }
    }

    static void scheduleOne(Context context, String id, String name, String type, String time, int every) {
        AlarmManager am = (AlarmManager) context.getSystemService(ALARM_SERVICE);
        if (am == null) return;
        long when;
        if (every > 0) when = System.currentTimeMillis() + Math.max(1, every) * 60_000L;
        else {
            int hour=9, minute=0;
            try { String[] p=time.split(":"); hour=Integer.parseInt(p[0]); minute=Integer.parseInt(p[1]); } catch(Exception ignored) {}
            Calendar c=Calendar.getInstance(); c.set(Calendar.HOUR_OF_DAY,hour); c.set(Calendar.MINUTE,minute); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0);
            if (c.getTimeInMillis() <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR,1);
            when=c.getTimeInMillis();
        }
        Intent intent = new Intent(context, ReminderReceiver.class);
        intent.setAction("com.ak.discipline.REMINDER." + id);
        intent.putExtra("id",id); intent.putExtra("name",name); intent.putExtra("type",type); intent.putExtra("time",time); intent.putExtra("every",every);
        PendingIntent pi=PendingIntent.getBroadcast(context, id.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
                else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
            } else am.setExact(AlarmManager.RTC_WAKEUP,when,pi);
        } catch (SecurityException ex) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi); }
    }

    static void cancelAlarm(Context context, String id) {
        Intent intent=new Intent(context,ReminderReceiver.class); intent.setAction("com.ak.discipline.REMINDER."+id);
        PendingIntent pi=PendingIntent.getBroadcast(context,id.hashCode(),intent,PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);
        if(pi!=null){AlarmManager am=(AlarmManager)context.getSystemService(ALARM_SERVICE);if(am!=null)am.cancel(pi);pi.cancel();}
    }
    private void cancelAlarm(String id) { cancelAlarm(this,id); }

    public class AlarmBridge {
        private final Context context;
        AlarmBridge(Context c) { context=c.getApplicationContext(); }
        @JavascriptInterface public void syncReminders(String json) {
            SharedPreferences prefs=getSharedPreferences(PREFS,MODE_PRIVATE);
            String old=prefs.getString(REMINDERS,"[]");
            try { JSONArray prior=new JSONArray(old); for(int i=0;i<prior.length();i++){JSONObject r=prior.optJSONObject(i);if(r!=null)cancelAlarm(r.optString("id",""));} } catch(Exception ignored){}
            prefs.edit().putString(REMINDERS,json).apply();
            runOnUiThread(() -> scheduleAll(json));
        }
        @JavascriptInterface public void requestAlarmPermissions() {
            runOnUiThread(() -> {
                requestNotificationPermissionIfNeeded();
                if (Build.VERSION.SDK_INT >= 31) {
                    AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
                    if(am!=null && !am.canScheduleExactAlarms()) {
                        try { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName()))); }
                        catch(Exception ignored) { }
                    }
                }
            });
        }
        @JavascriptInterface public void testAlarm() {
            runOnUiThread(() -> ReminderReceiver.showNotification(MainActivity.this,"test","A.K. OS test alert","Test",true));
        }
    }

    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
