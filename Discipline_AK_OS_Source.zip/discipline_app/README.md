# Discipline — A.K. OS (v1.1 source)

## Build
1. Upload/replace the files in your GitHub repository, keeping `.github/workflows` intact.
2. Run the existing `Build Discipline APK` GitHub Actions workflow.
3. Download the `Discipline-debug-APK` artifact from the successful run.

## v1.1 additions
- Gamified quest-style dashboard and visual refresh.
- Calendar/task mission list with manual completion and XP.
- Reminder center for water, meals, gym, study and custom reminders.
- In-app vibration/notification requests while the app is active.
- Subject list and individual assignment/homework/self-study tasks.
- Body weight and measurements history.
- Saved meal templates with one-tap logging.
- Optional habit rest days and a missed-build-habit fine review when the app is opened.

## Important limitations
- This project uses a WebView-based HTML app. Reminders are not guaranteed when the app is closed, force-stopped, or restricted by Android battery settings. Reliable silent-mode alarms require native Android AlarmManager/notifications and user permissions; Do Not Disturb can still affect alerts.
- Automatic habit fines are processed when the app is opened on a new day; the app cannot know whether a real-world habit was completed unless you record it.
- Before installing a new debug APK, export your app backup. GitHub-hosted runners can generate different debug signing keys on different runs. If Android rejects an in-place update because of a signature mismatch, export/restore data if supported, then uninstall the old app and install the new APK. Uninstalling may erase local data.
- This is a personal-use debug build, not a Play Store release.
