# Discipline — A.K. OS (personal offline tracker)

Original, self-contained offline-first prototype created for personal use. The UI is branded **Discipline** with a dark default theme and light-mode toggle. It uses local browser/app storage and does not request network permission.

## Included in this MVP
- Dashboard with XP, levels, coins, daily score, habits, water/protein and cashflow snapshot
- Create/build habits and break-habit tracking
- Manual income/expense transactions, category, date, transaction reference, notes and local receipt attachment
- Water intake entries and configurable daily target
- Manual meal logging with calories and protein, configurable targets
- Study sessions, subjects, assignment counts, notes and stopwatch
- Gym/workout logs, sets/reps/load, weight check-ins and optional progress photos
- Goals and skill progress with units and due dates
- Focus stopwatch, saved sessions
- Basic charts, achievement cabinet, dark/light theme
- JSON backup/restore, CSV transaction export, text summary export

## Important limitations
This package is the complete app source and an Android Studio WebView project, **not a precompiled APK**. The build environment used to prepare it does not have the Android SDK/Gradle installed, so I could not honestly produce or test a signed installable APK here. Open the `android` folder in Android Studio and build **Build > Build APK(s)**. Android Studio will install/download the required build tools. The debug APK will normally appear under `android/app/build/outputs/apk/debug/app-debug.apk`.

## Quick use without compiling
Open `index.html` on your Android phone in a modern browser. It runs offline once saved locally. For app-like access, use your browser's Add to Home screen option where supported. The browser version stores data in that browser's local storage.

## Data & privacy
- No network permission, analytics, account, or cloud sync is included.
- Records remain on the device in local storage. Export a JSON backup regularly; clearing app/browser data can erase them.
- Images/PDFs are capped at 1.5 MB each to reduce local storage problems.
- The stopwatch measures elapsed time while the app is backgrounded, but mobile OS/browser suspension can affect live display and should be tested on the target phone.
- Fine/reward rules are intentionally simple in this first version. This MVP does not yet implement hundreds of achievements, automatic recurring reminders, biometric lock, widgets, PDF report export, automatic scheduled backups, cloud sync, or background Android foreground-service timers.

## Android build
- Open `android/` in Android Studio.
- Allow Android Studio to install SDK 35 and compatible Gradle tooling if prompted.
- Select Build > Build APK(s).
- For personal sideloading, install the generated debug APK. For a distributable release, create your own signing key in Android Studio.
